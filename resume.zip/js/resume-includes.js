$(function(){
$("#includedNavbar").load("navbar.html"); 
});